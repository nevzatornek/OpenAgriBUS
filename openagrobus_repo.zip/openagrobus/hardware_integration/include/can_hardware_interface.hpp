#pragma once
#include "../isobus/include/can_message.hpp"
#include <functional>

namespace openagrobus {

class ICanDriver {
public:
    virtual ~ICanDriver() = default;
    virtual bool send(const CanMessage& message) = 0;
    virtual void setReceiveCallback(std::function<void(const CanMessage&)> cb) = 0;
    virtual bool setFilter(uint32_t pgn, uint32_t mask) = 0;
    virtual bool getBusStatus() const = 0;
    virtual bool initialize(uint32_t baudRate = 250000) = 0;
};

} // namespace openagrobus
