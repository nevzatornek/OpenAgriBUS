# Contributing to OpenAgroBus

Thank you for your interest in contributing to OpenAgroBus!

## How to Contribute

1. **Fork** the repository
2. **Clone** your fork: `git clone https://github.com/YOUR_USERNAME/openagrobus.git`
3. **Create a branch**: `git checkout -b feature/your-feature-name`
4. **Make changes** following the coding standards below
5. **Run tests**: `ctest --test-dir build --output-on-failure`
6. **Commit**: `git commit -m 'feat: add your feature description'`
7. **Push**: `git push origin feature/your-feature-name`
8. **Open a Pull Request**

## Coding Standards

- C++17 standard
- clang-format style (run `clang-format -i` before committing)
- cppcheck must pass with no errors
- All new modules must have unit tests in `tests/unit/`
- Document public APIs with Doxygen comments

## Commit Message Format

```
type(scope): description

feat(gnss): add RTK/NTRIP client module
fix(can): correct bus-off recovery timing
docs(readme): update build instructions
test(seeder): add seed counter unit tests
```

## Reporting Issues

Please use GitHub Issues and include:
- Platform (Linux / Windows / STM32H7)
- Build system version
- Steps to reproduce
- Expected vs actual behavior
