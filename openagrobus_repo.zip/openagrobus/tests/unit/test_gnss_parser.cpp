#include <gtest/gtest.h>
// #include "gnss_processor.hpp"

TEST(GnssParserTest, ParseGGASentence) {
    // TODO: Test NMEA GGA parsing
    // Input:  "$GPGGA,123519,4807.038,N,01131.000,E,1,08,0.9,545.4,M,46.9,M,,*47"
    // Expect: lat=48.1173, lon=11.5167, fix=GPS, sats=8
    EXPECT_TRUE(true); // placeholder
}

TEST(GnssParserTest, ParseRMCSentence) {
    // TODO: Test NMEA RMC parsing
    EXPECT_TRUE(true); // placeholder
}

TEST(GnssParserTest, InvalidChecksumRejected) {
    // TODO: Test invalid NMEA checksum rejection
    EXPECT_TRUE(true); // placeholder
}
