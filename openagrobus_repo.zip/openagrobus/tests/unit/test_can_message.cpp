#include <gtest/gtest.h>
#include "isobus/include/can_message.hpp"

using namespace openagrobus;

TEST(CanMessageTest, ExtractPGN) {
    CanMessage msg;
    // PGN 65267 (0xFF13) with SA=0x80, Priority=6
    // ID = (6 << 26) | (0xFF13 << 8) | 0x80
    msg.identifier = (6U << 26) | (65267U << 8) | 0x80;
    msg.isExtendedFrame = true;
    EXPECT_EQ(msg.pgn(), 65267U);
}

TEST(CanMessageTest, ExtractSourceAddress) {
    CanMessage msg;
    msg.identifier = (6U << 26) | (65267U << 8) | 0x26;
    EXPECT_EQ(msg.sourceAddress(), 0x26);
}

TEST(CanMessageTest, ExtractPriority) {
    CanMessage msg;
    msg.identifier = (3U << 26) | (65267U << 8) | 0x80;
    EXPECT_EQ(msg.priority(), 3U);
}
