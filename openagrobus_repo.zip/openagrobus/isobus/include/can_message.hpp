#pragma once
#include <cstdint>

namespace openagrobus {

struct CanMessage {
    uint32_t identifier;
    uint8_t  data[8];
    uint8_t  dataLength;
    bool     isExtendedFrame;

    uint32_t pgn() const { return (identifier >> 8) & 0x3FFFF; }
    uint8_t  sourceAddress() const { return identifier & 0xFF; }
    uint8_t  priority() const { return (identifier >> 26) & 0x07; }
};

} // namespace openagrobus
