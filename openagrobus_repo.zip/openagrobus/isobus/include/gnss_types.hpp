#pragma once
#include <cstdint>

namespace openagrobus {

enum class GnssFixQuality : uint8_t {
    Invalid = 0, GPS = 1, DGPS = 2, RTKFixed = 4, RTKFloat = 5
};

struct GnssPosition {
    double latitude;
    double longitude;
    double altitude;
    GnssFixQuality fixQuality;
    uint8_t satelliteCount;
    float hdop;
    uint64_t timestamp_ms;
};

struct GnssVelocity {
    float speedMs;
    float courseRad;
    float headingRad;
    uint64_t timestamp_ms;
};

struct UtmPosition {
    double easting;
    double northing;
    int zone;
    char band;
};

} // namespace openagrobus
