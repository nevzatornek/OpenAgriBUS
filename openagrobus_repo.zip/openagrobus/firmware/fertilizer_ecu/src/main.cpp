/**
 * @file main.cpp
 * @brief OpenAgroBus — VRA Fertilizer Applicator ECU
 * Machine: Variable Rate Granular Fertilizer Applicator
 * MCU:     STM32H743 @ 480 MHz | RTOS: FreeRTOS
 */
#include <cstdio>

int main() {
    // TODO: HAL_Init() / SystemClock_Config()
    // TODO: Initialize FDCAN1 (ISOBUS) + FDCAN2 (J1939)
    // TODO: Initialize USART2 DMA for GNSS
    // TODO: Start FreeRTOS tasks:
    //   - CAN_RX_Task     (priority: highest)
    //   - GNSS_Task       (priority: high)
    //   - Control_Task    (priority: normal, 10ms period)
    //   - ISOBUS_Task     (priority: normal)
    //   - Logger_Task     (priority: low)
    // TODO: vTaskStartScheduler()
    printf("OpenAgroBus Fertilizer ECU v0.1.0\n");
    return 0;
}
