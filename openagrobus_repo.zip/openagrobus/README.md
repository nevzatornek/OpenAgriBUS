# OpenAgroBus

**Open-source ISOBUS (ISO 11783) software framework for precision agriculture machines**

[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![C++17](https://img.shields.io/badge/C%2B%2B-17-blue.svg)](https://isocpp.org/)
[![CMake](https://img.shields.io/badge/Build-CMake-red.svg)](https://cmake.org/)
[![Platform](https://img.shields.io/badge/Platform-STM32H7%20%7C%20Linux%20%7C%20Windows-lightgrey.svg)]()

---

## Overview

OpenAgroBus is a layered, platform-independent C++17 framework that enables agricultural implement ECUs to communicate over **ISOBUS (ISO 11783 / CAN 250 kbit/s)**.

Built on top of [AgIsoStack++](https://github.com/Open-Agriculture/AgIsoStack-plus-plus) (MIT), OpenAgroBus adds:

- **GNSS processing** — NMEA/UBX parser, WGS84→UTM, overlap detection, RTK/NTRIP
- **Variable Rate Application (VRA)** — speed-adaptive dosing with PID closed-loop
- **Section Control** — per-row / per-boom independent on/off with overlap prevention
- **Machine-specific firmware** — fertilizer applicator, sprayer, smart seeder
- **STM32H7 HAL** — FDCAN, PWM, ADC, FreeRTOS BSP

---

## Supported Machine Types

| Machine | Firmware | Key Modules |
|---------|----------|-------------|
| VRA Fertilizer Applicator | `firmware/fertilizer_ecu/` | Rate Controller, Dosage Engine, Fan Control |
| VRA Sprayer with Section Control | `firmware/sprayer_ecu/` | Section Control (8 ch.), Pressure, Boom Height |
| Smart Seeder | `firmware/seeder_ecu/` | Seed Counter, Depth Monitor, Row Closing |

---

## Architecture — Layer Overview

```
┌─────────────────────────────────────────────────────┐
│  LAYER 0  │  Tractor & ISOBUS Network               │
│           │  VT Server · TC Server · TECU · GNSS    │
├─────────────────────────────────────────────────────┤
│  LAYER 1  │  HAL / BSP  (openagrobus/hal/)          │
│           │  STM32H7 · FreeRTOS · FDCAN · PWM · ADC │
├─────────────────────────────────────────────────────┤
│  LAYER 2  │  CAN Abstraction  (isobus/can/)         │
│           │  STM32 · SocketCAN · PCAN-USB drivers   │
├─────────────────────────────────────────────────────┤
│  LAYER 3  │  ISO 11783 Transport / Network          │
│           │  PGN Codec · TP/ETP · Address Claim     │
├─────────────────────────────────────────────────────┤
│  LAYER 4  │  ISOBUS Application  (isobus/)          │
│           │  VT Client · TC Client · WS Client      │
├─────────────────────────────────────────────────────┤
│  LAYER 5  │  GNSS Processing                        │
│           │  NMEA Parser · UTM · Overlap Detector   │
├─────────────────────────────────────────────────────┤
│  LAYER 6  │  Machine Application Modules            │
│           │  Rate Ctrl · Section Ctrl · Alarm Mgr   │
├─────────────────────────────────────────────────────┤
│  LAYER 7  │  Hardware Outputs                       │
│           │  Solenoids · Pump · Fan · Sensors       │
└─────────────────────────────────────────────────────┘
```

---

## Project Structure

```
openagrobus/
├── isobus/                    # ISOBUS stack (based on AgIsoStack++)
│   ├── include/               # Public headers
│   └── src/                   # Implementation
├── hardware_integration/      # CAN hardware abstraction
│   ├── include/
│   └── src/
├── hal/                       # Hardware Abstraction Layer
│   ├── stm32/                 # STM32H7 BSP — FDCAN, PWM, ADC, FreeRTOS
│   ├── linux/                 # SocketCAN driver — development/test
│   └── windows/               # PCAN-USB driver — development/debug
├── firmware/                  # Machine-specific ECU applications
│   ├── fertilizer_ecu/        # VRA Fertilizer Applicator
│   ├── sprayer_ecu/           # VRA Sprayer with Section Control
│   └── seeder_ecu/            # Smart Seeder
├── tools/                     # Developer tools
│   ├── vt_designer/           # VT Object Pool designer (Python/Qt)
│   ├── pgn_analyzer/          # CAN bus PGN analyzer
│   └── simulator/             # ISOBUS network simulator
├── docs/                      # Documentation
├── tests/                     # Unit & integration tests
│   ├── unit/
│   └── integration/
├── examples/                  # Example applications
├── .github/workflows/         # CI/CD — GitHub Actions
├── CMakeLists.txt             # Top-level build system
└── README.md
```

---

## Getting Started

### Prerequisites

```bash
# Linux / macOS
sudo apt install cmake ninja-build gcc-arm-none-eabi can-utils

# Python tools
pip install pyserial pyqt5

# For Windows (PCAN-USB)
# Install PEAK PCAN drivers from https://www.peak-system.com
```

### Build — Linux (SocketCAN / PC test)

```bash
git clone https://github.com/YOUR_USERNAME/openagrobus.git
cd openagrobus
git submodule update --init --recursive

mkdir build && cd build
cmake .. -DPLATFORM=linux -GNinja
ninja
```

### Build — STM32H7

```bash
mkdir build_stm32 && cd build_stm32
cmake .. -DPLATFORM=stm32h7 \
         -DCMAKE_TOOLCHAIN_FILE=../hal/stm32/toolchain_stm32h7.cmake \
         -GNinja
ninja
```

### Flash — STM32H7

```bash
openocd -f interface/stlink.cfg -f target/stm32h7x.cfg \
        -c "program openagrobus.elf verify reset exit"
```

---

## GNSS Data Flow

```
u-blox F9P → UART DMA → NMEA/UBX Parser
    → WGS84 Lat/Lon → UTM Conversion
        → Field Map Update (25 Hz)
            → Overlap Detection
                → Section/Row Control Command
```

**Key PGNs:**
- `PGN 65267` — Machine position (Lat/Lon/Alt)
- `PGN 65256` — Ground speed / heading
- `PGN 0xFE52` — Section control status
- `PGN 0xFE49` — VRA rate setpoint
- `PGN 0xFE4A` — VRA actual rate

---

## ISO 11783 Standards

| Standard | Description |
|----------|-------------|
| ISO 11783-2 | Physical layer — CAN |
| ISO 11783-3 | Data link layer — PGN |
| ISO 11783-5 | Network management — Address Claim |
| ISO 11783-6 | Virtual Terminal (VT) |
| ISO 11783-7 | Implement messages / Working Set |
| ISO 11783-10 | Task Controller (TC) — VRA |
| ISO 11783-12 | Diagnostics — DTC / DM1 / DM2 |

---

## Hardware

| Component | Model | Interface |
|-----------|-------|-----------|
| MCU | STM32H7 (480 MHz Cortex-M7) | — |
| GNSS | u-blox ZED-F9P (RTK ±2 cm) | UART |
| CAN Transceiver | TJA1044 / MCP2562 | FDCAN |
| ISOBUS Connector | 9-pin (ISO 11783) | CAN |
| J1939 Connector | Deutsch DT 9-pin | CAN |
| WiFi / BT | ESP32-S3 (802.11ac + BT 5.0) | SPI/UART |
| LoRa | SX1276 / RFM95W (868 MHz) | SPI |

---

## Credits & Acknowledgements

OpenAgroBus is built on top of:

- **[AgIsoStack++](https://github.com/Open-Agriculture/AgIsoStack-plus-plus)** by Open-Agriculture Developers — MIT License
- **[FreeRTOS](https://www.freertos.org/)** — MIT License
- **[STM32CubeH7](https://github.com/STMicroelectronics/STM32CubeH7)** — BSD 3-Clause

---

## License

```
MIT License

Copyright (c) 2025 OpenAgroBus Contributors

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.
```

See [LICENSE](LICENSE) for full text.

---

## Contributing

Pull requests are welcome. Please read [CONTRIBUTING.md](docs/CONTRIBUTING.md) before submitting.

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request
